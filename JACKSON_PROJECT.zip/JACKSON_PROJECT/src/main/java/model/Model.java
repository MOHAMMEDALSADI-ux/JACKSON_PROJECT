package model;

import java.io.File;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Model {

	@JsonProperty("Source")
	private String source;

	@JsonProperty("requestId")
	private String requestId;

	@JsonProperty("createDate")
	private String createDate;

	@JsonProperty("data")
	private Data data;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public static class Data {

		@JsonProperty("bccCustomerNumber")
		private long bccCustomerNumber;

		@JsonProperty("bccSubProductsId")
		private long bccSubProductsId;

		@JsonProperty("bccContractNumber")
		private long bccContractNumber;

		@JsonProperty("workFlowID")
		private long workFlowID;

		@JsonProperty("batch")
		private boolean batch;

		@JsonProperty("isBatch")
		private boolean isBatch;

		@JsonProperty("parameters")
		private List<Parameters> parameters;

		public long getBccCustomerNumber() {
			return bccCustomerNumber;
		}

		public void setBccCustomerNumber(long bccCustomerNumber) {
			this.bccCustomerNumber = bccCustomerNumber;
		}

		public long getBccSubProductsId() {
			return bccSubProductsId;
		}

		public void setBccSubProductsId(long bccSubProductsId) {
			this.bccSubProductsId = bccSubProductsId;
		}

		public long getBccContractNumber() {
			return bccContractNumber;
		}

		public void setBccContractNumber(long bccContractNumber) {
			this.bccContractNumber = bccContractNumber;
		}

		public long getWorkFlowID() {
			return workFlowID;
		}

		public void setWorkFlowID(long workFlowID) {
			this.workFlowID = workFlowID;
		}

		public boolean getBatch() {
			return batch;
		}

		public void setBatch(boolean batch) {
			this.batch = batch;
		}

		public boolean getIsBatch() {
			return isBatch;
		}

		public void setIsBatch(boolean isBatch) {
			this.isBatch = isBatch;
		}

		public List<Parameters> getParameters() {
			return parameters;
		}

		public void setParameters(List<Parameters> parameters) {
			this.parameters = parameters;
		}

	}

}
