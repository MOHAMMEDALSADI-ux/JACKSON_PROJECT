package main;

import java.io.FileReader;
import java.util.List;

import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import model.Model;
import model.Parameters;

public class JackSon {

	@SuppressWarnings("deprecation")
	public void parser() {

		try {

			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

			Model model = mapper.readValue(new FileReader(
					"C:\\Users\\m.alsadi\\eclipse-workspace\\JACKSON_PROJECT\\src\\main\\resources\\Employee.json"),
					Model.class);

//			Config appConfig = Model.parseFile(new File(
//					"C:\\Users\\m.alsadi\\eclipse-workspace\\JACKSON_PROJECT\\src\\main\\resources\\Employee.json"))
//					.withFallback(Model.systemEnvironment());
			
			System.out.println(model.getSource());

			List<Parameters> list = model.getData().getParameters();

			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).getFirstName());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
